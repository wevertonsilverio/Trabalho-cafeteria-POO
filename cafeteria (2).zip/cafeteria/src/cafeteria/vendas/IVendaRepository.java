package cafeteria.vendas;

import cafeteria.vendas.clientes.Cliente;

import java.util.List;
import java.util.Optional;

public interface IVendaRepository {
    void registrarVenda(Venda venda);
    Optional<Venda> buscarPorId(int id);
    List<Venda> listarVendasDoDia();
    List<Cliente> listarMelhoresClientes();
}
