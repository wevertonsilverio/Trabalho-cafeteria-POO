package cafeteria.vendas;

import cafeteria.DB.DatabaseConnection;
import cafeteria.vendas.clientes.Cliente;
import cafeteria.vendas.clientes.ClienteRepository;
import cafeteria.vendas.produtos.UnidadeMedida;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class VendaRepository implements IVendaRepository {

    @Override
    public void registrarVenda(Venda venda) {
        String sqlVenda = "INSERT INTO venda (data_hora, cliente_id, desconto) VALUES (?, ?, ?)";
        String sqlItemVenda = "INSERT INTO item_venda (venda_id, nome, medida, quantidade, preco) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda, Statement.RETURN_GENERATED_KEYS)) {
                stmtVenda.setTimestamp(1, Timestamp.valueOf(venda.getDataHora()));
                stmtVenda.setInt(2, venda.getCliente().getId());
                stmtVenda.setDouble(3, venda.getDesconto());
                stmtVenda.executeUpdate();

                ResultSet rs = stmtVenda.getGeneratedKeys();
                if (rs.next()) {
                    venda.setId(rs.getInt(1));
                } else {
                    throw new SQLException("Erro ao obter o ID da venda.");
                }
            }

            try (PreparedStatement stmtItemVenda = conn.prepareStatement(sqlItemVenda)) {
                for (ItemVenda item : venda.getItens()) {
                    stmtItemVenda.setInt(1, venda.getId());
                    stmtItemVenda.setString(2, item.getNome());
                    stmtItemVenda.setInt(3, item.getMedida().ordinal() + 1);
                    stmtItemVenda.setInt(4, item.getQuantidade());
                    stmtItemVenda.setDouble(5, item.getPreco());
                    stmtItemVenda.executeUpdate();
                }
            }

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                DatabaseConnection.getConnection().rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
        }
    }


    @Override
    public Optional<Venda> buscarPorId(int id) {
        String sqlVenda = "SELECT * FROM venda WHERE id = ?";
        String sqlItens = "SELECT * FROM item_venda WHERE venda_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda);
             PreparedStatement stmtItens = conn.prepareStatement(sqlItens)) {

            // Busca a venda pelo ID
            stmtVenda.setInt(1, id);
            ResultSet rsVenda = stmtVenda.executeQuery();

            if (rsVenda.next()) {
                // Mapeia os dados da venda
                Venda venda = new Venda();
                venda.setId(rsVenda.getInt("id"));
                venda.setDataHora(rsVenda.getTimestamp("data_hora").toLocalDateTime());
                venda.setDesconto(rsVenda.getDouble("desconto"));

                // Busca e associa o cliente
                int clienteId = rsVenda.getInt("cliente_id");
                Optional<Cliente> clienteOpt = new ClienteRepository().buscarPorId(clienteId);
                if (clienteOpt.isEmpty()) {
                    throw new SQLException("Cliente não encontrado para a venda.");
                }
                venda.setCliente(clienteOpt.get());

                // Busca os itens da venda
                stmtItens.setInt(1, venda.getId());
                ResultSet rsItens = stmtItens.executeQuery();
                List<ItemVenda> itens = new ArrayList<>();
                while (rsItens.next()) {
                    ItemVenda item = new ItemVenda();
                    item.setId(rsItens.getInt("id"));
                    item.setNome(rsItens.getString("nome"));
                    item.setMedida(UnidadeMedida.values()[rsItens.getInt("medida") - 1]);
                    item.setQuantidade(rsItens.getInt("quantidade"));
                    item.setPreco(rsItens.getDouble("preco"));
                    itens.add(item);
                }
                venda.getItens().addAll(itens);

                return Optional.of(venda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return Optional.empty();
    }


    @Override
    public List<Venda> listarVendasDoDia() {
        List<Venda> vendasDoDia = new ArrayList<>();
        String sqlVendas = """
        SELECT v.id, v.data_hora, v.desconto
        FROM venda v
        WHERE DATE(v.data_hora) = CURRENT_DATE
    """;

        String sqlItens = """
        SELECT iv.nome, iv.medida, iv.quantidade, iv.preco
        FROM item_venda iv
        WHERE iv.venda_id = ?
    """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmtVendas = conn.prepareStatement(sqlVendas)) {

            ResultSet rsVendas = stmtVendas.executeQuery();

            while (rsVendas.next()) {
                Venda venda = new Venda();
                venda.setId(rsVendas.getInt("id"));
                venda.setDataHora(rsVendas.getTimestamp("data_hora").toLocalDateTime());
                venda.setDesconto(rsVendas.getDouble("desconto"));

                // Recuperar os itens da venda
                try (PreparedStatement stmtItens = conn.prepareStatement(sqlItens)) {
                    stmtItens.setInt(1, venda.getId());
                    ResultSet rsItens = stmtItens.executeQuery();

                    while (rsItens.next()) {
                        ItemVenda item = new ItemVenda();
                        item.setNome(rsItens.getString("nome"));
                        item.setMedida(UnidadeMedida.values()[rsItens.getInt("medida") - 1]);
                        item.setQuantidade(rsItens.getInt("quantidade"));
                        item.setPreco(rsItens.getDouble("preco"));

                        venda.adicionarItem(item);
                    }
                }

                // Calcular o valor total com base nos itens e desconto
                venda.setDesconto(venda.getDesconto()); // Atualiza o valor total internamente
                vendasDoDia.add(venda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vendasDoDia;
    }


    @Override
    public List<Cliente> listarMelhoresClientes() {
        String sql = """
        SELECT c.id AS cliente_id, c.nome AS cliente_nome, c.telefone AS cliente_telefone,
               SUM(iv.quantidade * iv.preco) - SUM(v.desconto) AS total_gasto
        FROM cliente c
        JOIN venda v ON v.cliente_id = c.id
        JOIN item_venda iv ON iv.venda_id = v.id
        GROUP BY c.id, c.nome, c.telefone
        ORDER BY total_gasto DESC
        LIMIT 10
    """;

        List<Cliente> melhoresClientes = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("cliente_id"));
                cliente.setNome(rs.getString("cliente_nome"));
                cliente.setTelefone(rs.getString("cliente_telefone"));

                // Adicionando o total gasto como atributo temporário no campo `nome` para evitar DTO
                cliente.setNome(cliente.getNome() + " | Total Gasto: R$ " + String.format("%.2f", rs.getDouble("total_gasto")));

                melhoresClientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return melhoresClientes;
    }

}
