package cafeteria.vendas.relatorios;

import cafeteria.vendas.ItemVenda;
import cafeteria.vendas.Venda;

public class RelatorioVendasDoDia extends RelatorioBase<Venda> {

    public RelatorioVendasDoDia(Iterable<Venda> vendas) {
        super(vendas);
    }

    @Override
    public String getNomeRelatorio() {
        return "Relatório de Vendas do Dia";
    }

    @Override
    protected String gerarConteudo() {
        StringBuilder builder = new StringBuilder("Relatório de Vendas do Dia\n");
        builder.append("============================\n");

        for (Venda venda : dados) {
            builder.append("Venda ID: ").append(venda.getId()).append("\n");
            builder.append("Data/Hora: ").append(venda.getDataHora()).append("\n");
            builder.append("Desconto: R$ ").append(venda.getDesconto()).append("\n");
            builder.append("Valor Total: R$ ").append(venda.getValorTotal()).append("\n");
            builder.append("Itens:\n");

            for (ItemVenda item : venda.getItens()) {
                builder.append("- ").append(item.getNome())
                        .append(" | Quantidade: ").append(item.getQuantidade())
                        .append(" | Preço Unitário: R$ ").append(item.getPreco())
                        .append(" | Total: R$ ").append(item.calcularValorTotal()).append("\n");
            }

            builder.append("--------------------------\n");
        }

        builder.append("Total de Vendas: ").append(((Iterable<?>) dados).spliterator().getExactSizeIfKnown()).append("\n");
        return builder.toString();
    }
}
