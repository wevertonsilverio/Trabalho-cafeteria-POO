package cafeteria.vendas.relatorios.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ExportadorDeArquivos {

    public static void exportar(String conteudo, File destino) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(destino))) {
            writer.write(conteudo);
        }
    }
}
