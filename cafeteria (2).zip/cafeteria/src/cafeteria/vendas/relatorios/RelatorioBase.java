package cafeteria.vendas.relatorios;

import cafeteria.vendas.relatorios.utils.ExportadorDeArquivos;

import java.io.File;
import java.io.IOException;

public abstract class RelatorioBase<T> implements RelatorioExportavelEmArquivoTexto {
    protected final Iterable<T> dados;

    public RelatorioBase(Iterable<T> dados) {
        this.dados = dados;
    }

    protected abstract String gerarConteudo();

    @Override
    public void exportar(File destino) {
        try {
            ExportadorDeArquivos.exportar(gerarConteudo(), destino);
        } catch (IOException e) {
            System.err.println("Erro ao exportar relatório: " + e.getMessage());
        }
    }
}
