package cafeteria.vendas.relatorios;

import cafeteria.vendas.clientes.Cliente;

public class RelatorioMelhoresClientes extends RelatorioBase<Cliente> {

    public RelatorioMelhoresClientes(Iterable<Cliente> clientes) {
        super(clientes);
    }

    @Override
    public String getNomeRelatorio() {
        return "Relatório de Melhores Clientes";
    }

    @Override
    protected String gerarConteudo() {
        StringBuilder builder = new StringBuilder("Relatório de Melhores Clientes\n\n");

        for (Cliente cliente : dados) {
            builder.append("ID: ").append(cliente.getId()).append("\n")
                    .append("Nome e Total Gasto: ").append(cliente.getNome()).append("\n")
                    .append("Telefone: ").append(cliente.getTelefone()).append("\n")
                    .append("-----------------------\n");
        }

        builder.append("Total de Clientes no Relatório: ")
                .append(((Iterable<?>) dados).spliterator().getExactSizeIfKnown())
                .append("\n");

        return builder.toString();
    }
}
