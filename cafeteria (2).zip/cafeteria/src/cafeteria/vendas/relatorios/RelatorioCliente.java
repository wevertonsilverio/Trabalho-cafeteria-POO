package cafeteria.vendas.relatorios;

import cafeteria.vendas.clientes.Cliente;

public class RelatorioCliente extends RelatorioBase<Cliente> {

    public RelatorioCliente(Iterable<Cliente> clientes) {
        super(clientes);
    }

    @Override
    public String getNomeRelatorio() {
        return "Relatório de Clientes";
    }

    @Override
    protected String gerarConteudo() {
        StringBuilder builder = new StringBuilder("Relatório de Clientes\n");
        int totalClientes = 0;

        if (!dados.iterator().hasNext()) {
            builder.append("Nenhum cliente encontrado.\n");
            return builder.toString();
        }

        for (Cliente cliente : dados) {
            builder.append("ID: ").append(cliente.getId()).append("\n");
            builder.append("Nome: ").append(cliente.getNome()).append("\n");
            builder.append("Telefone: ").append(cliente.getTelefone()).append("\n");
            builder.append("-----------------------\n");
            totalClientes++;
        }
        builder.append("Total de Clientes: ").append(totalClientes).append("\n");
        return builder.toString();
    }
}
