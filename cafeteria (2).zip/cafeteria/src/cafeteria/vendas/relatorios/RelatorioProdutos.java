package cafeteria.vendas.relatorios;

import cafeteria.vendas.produtos.EstoqueProduto;
import cafeteria.vendas.produtos.Produto;

public class RelatorioProdutos extends RelatorioBase<Produto> {

    public RelatorioProdutos(Iterable<Produto> produtos) {
        super(produtos);
    }

    @Override
    public String getNomeRelatorio() {
        return "Relatório de Produtos";
    }

    @Override
    protected String gerarConteudo() {
        StringBuilder builder = new StringBuilder("Relatório de Produtos\n");

        for (Produto produto : dados) {
            builder.append("ID: ").append(produto.getId()).append("\n");
            builder.append("Nome: ").append(produto.getNome()).append("\n");
            builder.append("Medida: ").append(produto.getMedida()).append("\n");
            builder.append("Preço: ").append(produto.getPreco()).append("\n");

            // Aproveitando o polimorfismo em vez de instanceof
            if (produto instanceof EstoqueProduto estoqueProduto) {
                builder.append("Estoque: ").append(estoqueProduto.getEstoque()).append("\n");
            } else {
                builder.append("Estoque: Não aplicável\n");
            }

            builder.append("-----------------------\n");
        }

        return builder.toString();
    }
}
