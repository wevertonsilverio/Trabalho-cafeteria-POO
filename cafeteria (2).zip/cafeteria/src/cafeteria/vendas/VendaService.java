package cafeteria.vendas;

import cafeteria.vendas.clientes.Cliente;

import java.util.List;

public class VendaService implements IVendaService {

    private final IVendaRepository vendaRepository;

    public VendaService(IVendaRepository vendaRepository) {
        this.vendaRepository = vendaRepository;
    }

    @Override
    public void registrarVenda(Venda venda) {
        // Lógica de negócios, ex.: validar estoque
        vendaRepository.registrarVenda(venda);
    }

    @Override
    public Venda buscarPorId(int id) {
        return vendaRepository.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Venda não encontrada."));
    }

    @Override
    public List<Venda> listarVendasDoDia() {
        return vendaRepository.listarVendasDoDia();
    }

    @Override
    public List<Cliente> listarMelhoresClientes() {
        return vendaRepository.listarMelhoresClientes();
    }
}
