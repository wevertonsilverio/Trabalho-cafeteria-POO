package cafeteria.vendas;

import cafeteria.vendas.clientes.Cliente;

import java.util.List;

public interface IVendaService {

    void registrarVenda(Venda venda);
    Venda buscarPorId(int id);
    List<Venda> listarVendasDoDia();
    List<Cliente> listarMelhoresClientes();

}
