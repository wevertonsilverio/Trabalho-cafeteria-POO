package cafeteria.vendas.clientes;

import java.util.List;
import java.util.Optional;

public class ClienteService implements IClienteService {

    private final IClienteRepository clienteRepository;

    // Construtor com injeção do repositório
    public ClienteService(IClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    @Override
    public void salvar(Cliente cliente) {
        // Validações de negócio
        if (cliente.getNome() == null || cliente.getNome().isEmpty()) {
            throw new IllegalArgumentException("O nome do cliente é obrigatório.");
        }

        if (cliente.getTelefone() == null || cliente.getTelefone().isEmpty()) {
            throw new IllegalArgumentException("O telefone do cliente é obrigatório.");
        }

        // Delegar a persistência ao repositório
        clienteRepository.salvar(cliente);
    }

    @Override
    public Optional<Cliente> buscarPorId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID inválido.");
        }
        return clienteRepository.buscarPorId(id);
    }

    @Override
    public List<Cliente> listarTodos() {
        return clienteRepository.listarTodos();
    }
}
