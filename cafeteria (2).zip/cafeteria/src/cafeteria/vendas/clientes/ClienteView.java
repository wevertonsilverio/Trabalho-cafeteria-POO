package cafeteria.vendas.clientes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.Optional;

import javax.swing.*;
import javax.swing.text.MaskFormatter;

public class ClienteView extends JInternalFrame {

	private static final String TITULO = "Cadastro de Cliente";

	private static final int POSICAO_X_INICIAL = 30;
	private static final int POSICAO_Y_INICIAL = 30;

	private static final int LARGURA = 580;
	private static final int ALTURA = 210;

	private static final long serialVersionUID = 1L;

	private JTextField id;
	private JTextField nome;
	private JFormattedTextField telefone;

	private JButton btSalvar;
	private JButton btVoltar;
	private JButton btNovoCliente;
	private JButton btPesquisar;

	private IClienteService service = null;

	/**
	 * Cria a janela do CRUD do cliente
	 */
	public ClienteView(IClienteService service) {
		this.service = service;

		setClosable(true);
		setIconifiable(true);
		setSize(LARGURA, ALTURA);
		setLocation(POSICAO_X_INICIAL, POSICAO_Y_INICIAL);
		setTitle(TITULO);
		getContentPane().setLayout(null);

		JLabel lbId = new JLabel("ID:");
		lbId.setBounds(31, 40, 60, 17);
		getContentPane().add(lbId);

		id = new JTextField();
		id.setHorizontalAlignment(SwingConstants.CENTER);
		id.setBounds(109, 38, 114, 21);
		getContentPane().add(id);
		id.setColumns(10);

		JLabel lbNome = new JLabel("Nome:");
		lbNome.setBounds(31, 73, 60, 17);
		getContentPane().add(lbNome);

		nome = new JTextField();
		nome.setBounds(109, 71, 430, 21);
		getContentPane().add(nome);
		nome.setColumns(10);

		JLabel lbTelefone = new JLabel("Telefone:");
		lbTelefone.setBounds(31, 106, 60, 17);
		getContentPane().add(lbTelefone);

		MaskFormatter maskFormatter;
		try {
			maskFormatter = new MaskFormatter("(##) #####-####");
			maskFormatter.setPlaceholderCharacter('_'); // Caracter de espaço reservado
			telefone = new JFormattedTextField(maskFormatter);
			telefone.setBounds(109, 104, 132, 21);
			getContentPane().add(telefone);
			telefone.setColumns(10);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		btSalvar = new JButton("Salvar");
		btSalvar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				onClickSalvar();
			}
		});
		btSalvar.setBounds(434, 126, 105, 27);
		getContentPane().add(btSalvar);

		btVoltar = new JButton("Voltar");
		btVoltar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				onClickVoltar();
			}
		});
		btVoltar.setBounds(317, 126, 105, 27);
		getContentPane().add(btVoltar);

		btNovoCliente = new JButton("Novo Cliente");
		btNovoCliente.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				onClickIncluirNovoCliente();
			}
		});
		btNovoCliente.setBounds(400, 35, 139, 27);
		getContentPane().add(btNovoCliente);

		btPesquisar = new JButton("Pesquisar");
		btPesquisar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				onClickPesquisar();
			}
		});
		btPesquisar.setBounds(235, 35, 96, 27);
		getContentPane().add(btPesquisar);
	}

	/**
	 * Prepara o frame para a ação de consultar
	 */
	public void setupConsultar() {
		// configura os botões de ação
		btSalvar.setEnabled(false);
		btVoltar.setEnabled(false);
		btNovoCliente.setEnabled(true);
		btPesquisar.setEnabled(true);

		// configura o comportamento dos campos
		id.setEnabled(true);
		nome.setEnabled(false);
		telefone.setEnabled(false);
	}

	/**
	 * Executa as tarefas para efetuar uma pesquisa com base no ID informado
	 */
	protected void onClickPesquisar() {

		nome.setEnabled(true);
		telefone.setEnabled(true);
		btSalvar.setEnabled(true);
		btVoltar.setEnabled(true);
		btPesquisar.setEnabled(false);
		btNovoCliente.setEnabled(false);
		id.setEnabled(false);


		String idCliente = id.getText().trim();
		if (idCliente.isEmpty()) {
			System.out.println("ID não pode ser vazio.");
			return;
		}

		try {
			int idInt = Integer.parseInt(idCliente);

			Optional<Cliente> clienteOpt = service.buscarPorId(idInt);
			if (clienteOpt.isPresent()) {
				Cliente cliente = clienteOpt.get();
				nome.setText(cliente.getNome());
				telefone.setText(cliente.getTelefone());
			} else {
				System.out.println("Cliente não encontrado.");
			}
		} catch (NumberFormatException e) {
			System.out.println("ID inválido. Por favor, insira um número.");
		}
	}

	/**
	 * Executa as tarefas para preparar a interface para a inclusão de um novo
	 * cliente
	 */
	protected void onClickIncluirNovoCliente() {
		// Habilitar os campos para entrada de dados
		id.setEnabled(false); // ID será gerado automaticamente
		nome.setEnabled(true);
		telefone.setEnabled(true);

		// Habilitar os botões salvar e voltar
		btSalvar.setEnabled(true);
		btVoltar.setEnabled(true);

		// Limpar os campos
		nome.setText("");
		telefone.setText("");

	}

	/**
	 * Executa as tarefas para voltar a inclusão de um cliente
	 */
	protected void onClickVoltar() {
		// Voltar ao estado inicial
		btSalvar.setEnabled(false);
		btVoltar.setEnabled(false);
		btNovoCliente.setEnabled(true);
		btPesquisar.setEnabled(true);

		// Desabilitar os campos
		id.setEnabled(true);
		nome.setEnabled(false);
		telefone.setEnabled(false);
		nome.setText("");
		telefone.setText("");
	}

	/**
	 * Executa as tarefas para salvar a inclusão de um novo cliente
	 */
	protected void onClickSalvar() {

		String nomeCliente = nome.getText().trim();
		String telefoneCliente = telefone.getText().trim();

		// Validação: Nome e telefone são obrigatórios
		if (nomeCliente.isEmpty() || telefoneCliente.isEmpty()) {
			System.out.println("Nome e telefone são obrigatórios.");
			return;
		}

		Cliente cliente = new Cliente();
		cliente.setNome(nomeCliente);
		cliente.setTelefone(telefoneCliente);

		// Se o campo ID não está vazio, configurar o ID no objeto Cliente
		if (!id.getText().trim().isEmpty()) {
			try {
				cliente.setId(Integer.parseInt(id.getText().trim()));
			} catch (NumberFormatException e) {
				System.out.println("ID inválido.");
				return;
			}
		}

		// Salvar ou atualizar cliente
		service.salvar(cliente);

		if (cliente.getId() == 0) {
			System.out.println("Novo cliente salvo com sucesso.");
			JOptionPane.showMessageDialog(this, "Novo cliente salvo com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

		} else {
			System.out.println("Cliente atualizado com sucesso.");
			JOptionPane.showMessageDialog(this, "Cliente atualizado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
		}

		onClickVoltar();
		id.setText("");
	}


}
