package cafeteria.vendas.produtos;

import cafeteria.DB.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProdutoRepository implements IProdutoRepository {

    @Override
    public void salvar(Produto produto) {
        String sql = produto.getId() == 0
                ? "INSERT INTO produto (nome, medida, preco, estoque) VALUES (?, ?, ?, ?)"
                : "UPDATE produto SET nome = ?, medida = ?, preco = ?, estoque = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, produto.getNome());
            stmt.setInt(2, produto.getMedida().ordinal() + 1);
            stmt.setDouble(3, produto.getPreco());
            if (produto instanceof EstoqueProduto) {
                stmt.setInt(4, ((EstoqueProduto) produto).getEstoque());
            } else {
                stmt.setInt(4, 0);
            }
            if (produto.getId() != 0) {
                stmt.setInt(5, produto.getId());
            }

            stmt.executeUpdate();

            if (produto.getId() == 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    produto.setId(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Optional<Produto> buscarPorId(int id) {
        String sql = "SELECT * FROM produto WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Produto produto = mapProduto(rs);
                return Optional.of(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<Produto> buscarPorNome(String nome) {
        String sql = "SELECT * FROM produto WHERE nome = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Produto produto = mapProduto(rs);
                return Optional.of(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public List<Produto> listarTodos() {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT * FROM produto";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Produto produto = mapProduto(rs);
                produtos.add(produto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produtos;
    }

    private Produto mapProduto(ResultSet rs) throws SQLException {
        int estoque = rs.getInt("estoque");
        UnidadeMedida medida = UnidadeMedida.values()[rs.getInt("medida") - 1];
        if (estoque > 0) {
            return new EstoqueProduto(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    medida,
                    rs.getDouble("preco"),
                    estoque
            );
        } else {
            return new Produto(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    medida,
                    rs.getDouble("preco")
            );
        }
    }
}
