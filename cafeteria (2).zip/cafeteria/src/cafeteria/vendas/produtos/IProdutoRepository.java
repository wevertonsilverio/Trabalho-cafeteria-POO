package cafeteria.vendas.produtos;

import java.util.List;
import java.util.Optional;

public interface IProdutoRepository {
    void salvar(Produto produto);
    Optional<Produto> buscarPorId(int id);
    Optional<Produto> buscarPorNome(String nome);
    List<Produto> listarTodos();
}
