package cafeteria.vendas.produtos;

import java.util.List;

public interface IProdutoService {

    void salvar(Produto produto);
    Produto buscarPorId(int id);
    List<Produto> listarTodos();
    Produto buscarPorNome(String nome);


}
