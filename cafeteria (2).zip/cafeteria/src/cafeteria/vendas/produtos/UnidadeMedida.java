package cafeteria.vendas.produtos;

public enum UnidadeMedida {

	UNIDADE, LATA, LITRO, PACOTE, FATIA, GARRAFA

}
